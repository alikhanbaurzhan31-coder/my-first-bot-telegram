import json
import os
from pathlib import Path

from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# All project files are stored next to this script.
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

TOKEN = os.getenv("BOT_TOKEN")
DATA_FILE = BASE_DIR / "user.json"

NAME, COLOR, HOBBY, GAME, FOOD = range(5)


def load_users() -> dict:
    """Load saved user profiles. Return an empty dictionary if none exist yet."""
    if not DATA_FILE.exists():
        return {}

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
    except json.JSONDecodeError as exc:
        raise ValueError(
            "user.json содержит некорректный JSON. Проверь файл или восстанови его из резервной копии."
        ) from exc

    if not isinstance(data, dict):
        raise ValueError("user.json должен содержать JSON-объект.")

    return data


def save_users() -> None:
    """Write profiles to a temporary file, then safely replace user.json."""
    temporary_file = DATA_FILE.with_suffix(".tmp")
    with temporary_file.open("w", encoding="utf-8") as file:
        json.dump(users, file, ensure_ascii=False, indent=2)
        file.write("\n")
    temporary_file.replace(DATA_FILE)


# Load profiles on startup so data survives a restart.
users = load_users()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message is None:
        return
    await update.message.reply_text(
        "Привет! Я бот, который хранит твой профиль.\n\n"
        "Команды:\n"
        "/setprofile — заполнить или изменить профиль\n"
        "/profile — посмотреть сохранённые данные\n"
        "/cancel — отменить заполнение"
    )


async def set_profile(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None:
        return ConversationHandler.END
    context.user_data["profile_draft"] = {}
    await update.message.reply_text("Заполним 5 параметров.\n\n1/5. Как тебя зовут?")
    return NAME


async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None or update.message.text is None:
        return NAME
    context.user_data["profile_draft"]["name"] = update.message.text.strip()
    await update.message.reply_text("2/5. Какой твой любимый цвет?")
    return COLOR


async def get_color(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None or update.message.text is None:
        return COLOR
    context.user_data["profile_draft"]["favorite_color"] = update.message.text.strip()
    await update.message.reply_text("3/5. Какое у тебя хобби?")
    return HOBBY


async def get_hobby(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None or update.message.text is None:
        return HOBBY
    context.user_data["profile_draft"]["hobby"] = update.message.text.strip()
    await update.message.reply_text("4/5. Какая твоя любимая игра?")
    return GAME


async def get_game(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None or update.message.text is None:
        return GAME
    context.user_data["profile_draft"]["favorite_game"] = update.message.text.strip()
    await update.message.reply_text("5/5. Какая твоя любимая еда?")
    return FOOD


async def get_food(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message is None or update.message.text is None or update.effective_user is None:
        return FOOD

    context.user_data["profile_draft"]["favorite_food"] = update.message.text.strip()
    user_id = str(update.effective_user.id)
    users[user_id] = context.user_data.pop("profile_draft")
    save_users()

    await update.message.reply_text(
        "Готово! Профиль сохранён в user.json.\n"
        "Посмотреть его можно командой /profile."
    )
    return ConversationHandler.END


async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message is None or update.effective_user is None:
        return

    user_id = str(update.effective_user.id)
    saved_profile = users.get(user_id)
    if not saved_profile:
        await update.message.reply_text(
            "У тебя пока нет сохранённого профиля.\n"
            "Напиши /setprofile, чтобы заполнить его."
        )
        return

    await update.message.reply_text(
        "ТВОЙ ПРОФИЛЬ\n\n"
        f"Имя: {saved_profile.get('name', 'не указано')}\n"
        f"Любимый цвет: {saved_profile.get('favorite_color', 'не указано')}\n"
        f"Хобби: {saved_profile.get('hobby', 'не указано')}\n"
        f"Любимая игра: {saved_profile.get('favorite_game', 'не указано')}\n"
        f"Любимая еда: {saved_profile.get('favorite_food', 'не указано')}"
    )


async def profile_during_conversation(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    await profile(update, context)
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("profile_draft", None)
    if update.message is not None:
        await update.message.reply_text(
            "Заполнение отменено. Сохранённый профиль не изменён."
        )
    return ConversationHandler.END


async def start_during_conversation(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> int:
    await start(update, context)
    return ConversationHandler.END


def main() -> None:
    if not TOKEN:
        raise RuntimeError(
            "BOT_TOKEN не найден. Создай файл .env рядом с bot.py и добавь строку BOT_TOKEN=твой_новый_токен."
        )

    application = (
        Application.builder()
        .token(TOKEN)
        .concurrent_updates(False)
        .build()
    )

    conversation = ConversationHandler(
        entry_points=[CommandHandler("setprofile", set_profile)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            COLOR: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_color)],
            HOBBY: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_hobby)],
            GAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_game)],
            FOOD: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_food)],
        },
        fallbacks=[
            CommandHandler("cancel", cancel),
            CommandHandler("profile", profile_during_conversation),
            CommandHandler("start", start_during_conversation),
        ],
    )

    application.add_handler(conversation)
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("profile", profile))

    print("Бот запущен. Остановить можно сочетанием Ctrl+C.")
    application.run_polling()


if __name__ == "__main__":
    main()
