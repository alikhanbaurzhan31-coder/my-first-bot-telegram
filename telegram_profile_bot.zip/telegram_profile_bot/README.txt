НАСТРОЙКА TELEGRAM-БОТА

1. Отзови раскрытый ранее токен через @BotFather и получи новый.
2. Скопируй bot.py, .env.example и .gitignore в папку проекта.
3. Создай копию .env.example с именем .env (именно .env, без .txt).
4. Открой .env и замени значение после BOT_TOKEN= на новый токен.
5. В PowerShell выполни:
   python -m pip install python-telegram-bot python-dotenv
6. Перейди в папку с bot.py. Например:
   cd C:\Users\user\Downloads
7. Запусти:
   python bot.py

Данные профиля сохраняются в user.json рядом с bot.py. Не удаляй этот файл,
если хочешь сохранить данные между перезапусками.

ВАЖНО: Не публикуй .env и не отправляй токен другим людям.
